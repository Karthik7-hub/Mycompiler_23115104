#include <iostream>
extern int yyparse();

int main() {
    std::cout << "Enter code (e.g. RESULT = (X1 * Y1 + 1) + (X2 * Y2 + 1);):\n";
    yyparse();
    return 0;
}
